#Task_1.1
name = input("Enter First name: ")
print("First Name contains : ", len(name), "characters")