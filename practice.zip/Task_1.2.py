#Task_1.2
str = "The gave me 20$ and I returned them 30$"
print(str.count("$"))