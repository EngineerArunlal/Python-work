#Task_2
num_1 = float(input("Enter first number : "))
num_2 = float(input("Enter second number : "))

print("The average of both Numbers will be : ",(num_1+num_2)/2)