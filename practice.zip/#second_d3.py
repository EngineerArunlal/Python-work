#second_d3
str = 'I am Arun and I am learning Python programming language. I am enjoying it a lot.\n'
print(str)

print(str.startswith("I")) # Check if the string starts with "I"
print(str.endswith("n ")) # Check if the string ends with "n "
print(str.count("n")) # Count occurrences of "n"

print(str.find("Arun")) # Find the index of "Arun"