#second_d2
str1 = "Arun is available for You"
print(len(str1))
print(str1[2])
print(str1[2:9])