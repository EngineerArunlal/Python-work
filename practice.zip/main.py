#print('Hey there');
print("Hey there")
print('''Hello Arun''');
age = 18
print(age)
#age = 19
print(age)
