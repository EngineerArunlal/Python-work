#Task_3

num_1 = int(input("Enter first number : "))
num_2 = int(input("Enter second number : "))

result = num_1>= num_2;
print("Output : ",result)