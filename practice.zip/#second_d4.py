#second.d4
str = "yellow"
if(str == "green"):
    print("Go")
elif(str == "yellow"):
    print("Ready")
else:
    print("Stop")